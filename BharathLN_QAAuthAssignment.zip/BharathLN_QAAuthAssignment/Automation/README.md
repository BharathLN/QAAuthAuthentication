# Automation — Selenium + TestNG (Maven)

Target application: **https://demowebshop.tricentis.com** (public Tricentis demo e-commerce site, used as a stand-in target since the assignment's actual app URL was not provided — see `../../Assumptions.md`).

## Stack
- Java 11+
- Maven
- Selenium WebDriver 4.x
- TestNG
- WebDriverManager (auto-downloads the matching ChromeDriver — no manual setup needed)

## Project Structure
```
maven-project/
├── pom.xml
├── testng.xml
├── src/
│   ├── main/java/com/qa/auth/pages/
│   │   ├── RegisterPage.java
│   │   ├── LoginPage.java
│   │   └── MyAccountPage.java      # protected page, stand-in for "Dashboard"
│   └── test/java/com/qa/auth/
│       ├── BaseTest.java           # WebDriver setup/teardown
│       └── AuthenticationTest.java # the 5 required scenarios
```

## Scenarios Covered
1. Successful registration
2. Registration with duplicate email
3. Successful login
4. Login with invalid password
5. Access protected "My account" page without login → redirected to `/login`

## Setup
1. Install JDK 11+ and Maven.
2. Install/confirm Google Chrome is available (WebDriverManager handles the driver binary).
3. No application setup needed — tests run directly against the live public demo site.

## Run Tests
```bash
mvn clean test
```

Run with a visible (non-headless) browser, to watch it work:
```bash
mvn clean test -Dheadless=false
```

Point at a different base URL (e.g. your own deployed app once available):
```bash
mvn clean test -DbaseUrl=https://your-app-url.com
```
> Note: pointing at a different app will require updating the locators in `RegisterPage.java` / `LoginPage.java` / `MyAccountPage.java` to match that app's actual HTML — the current ones (`#FirstName`, `#Email`, `#Password`, etc.) are specific to demowebshop.tricentis.com's markup.

## Results
- Console output shows pass/fail per scenario.
- A surefire report is generated at `target/surefire-reports/` after each run.
- Screenshots/run output for submission should go in `../../Evidence/`.
