package com.qa.auth.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class RegisterPage {

    private WebDriver driver;

    private By firstName = By.id("FirstName");
    private By lastName = By.id("LastName");
    private By email = By.id("Email");
    private By password = By.id("Password");
    private By confirmPassword = By.id("ConfirmPassword");
    private By registerButton = By.id("register-button");
    private By successMessage = By.className("result");
    private By validationErrors = By.className("validation-summary-errors");

    public RegisterPage(WebDriver driver) {
        this.driver = driver;
    }

    public void open(String baseUrl) {
        driver.get(baseUrl + "/register");
    }

    public void register(String first, String last, String emailValue, String pass, String confirmPass) {
        driver.findElement(firstName).sendKeys(first);
        driver.findElement(lastName).sendKeys(last);
        driver.findElement(email).sendKeys(emailValue);
        driver.findElement(password).sendKeys(pass);
        driver.findElement(confirmPassword).sendKeys(confirmPass);
        driver.findElement(registerButton).click();
    }

    public boolean isRegistrationSuccessful() {
        return driver.findElements(successMessage).size() > 0
                && driver.findElement(successMessage).getText().contains("Your registration completed");
    }

    public String getValidationErrorText() {
        return driver.findElement(validationErrors).getText();
    }
}