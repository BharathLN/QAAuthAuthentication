package com.qa.auth.pages;

import org.openqa.selenium.WebDriver;

public class MyAccountPage {

    private WebDriver driver;

    public MyAccountPage(WebDriver driver) {
        this.driver = driver;
    }

    public void openDirectly(String baseUrl) {
        driver.get(baseUrl + "/customer/info");
    }

    public boolean isRedirectedToLogin() {
        return driver.getCurrentUrl().contains("/login");
    }
}