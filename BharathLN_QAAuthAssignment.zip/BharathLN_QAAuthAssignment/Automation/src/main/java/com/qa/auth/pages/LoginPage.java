package com.qa.auth.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {

    private WebDriver driver;

    private By email = By.id("Email");
    private By password = By.id("Password");
    private By loginButton = By.cssSelector("input.login-button");
    private By loginErrors = By.className("validation-summary-errors");
    private By logoutLink = By.className("ico-logout");

    public LoginPage(WebDriver driver) {
        this.driver = driver;
    }

    public void open(String baseUrl) {
        driver.get(baseUrl + "/login");
    }

    public void login(String emailValue, String passwordValue) {
        driver.findElement(email).sendKeys(emailValue);
        driver.findElement(password).sendKeys(passwordValue);
        driver.findElement(loginButton).click();
    }

    public boolean isLoggedIn() {
        return driver.findElements(logoutLink).size() > 0;
    }

    public String getLoginErrorText() {
        return driver.findElement(loginErrors).getText();
    }

    public void logout() {
        driver.findElement(logoutLink).click();
    }
}