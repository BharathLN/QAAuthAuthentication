import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import com.qa.auth.pages.RegisterPage;

public class RunRegister {
    WebDriver driver;
    RegisterPage registerPage;

    @BeforeMethod
    public void setUp() {
        // 1. Initialize browser before each test
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        
        // 2. Instantiate the page object
        registerPage = new RegisterPage(driver);
    }

    @Test
    public void testUserRegistration() {
        // 3. Open the registration page
        String baseUrl = "https://tricentis.com"; 
        registerPage.open(baseUrl);

        // 4. Fill and submit the form
        registerPage.register(
            "John", 
            "Doe", 
            "johndoe_test@example.com", 
            "SecurePass123", 
            "SecurePass123"
        );

        // 5. Hard assertion to verify success
        boolean isSuccess = registerPage.isRegistrationSuccessful();
        
        String errorMsg = "";
        if (!isSuccess) {
            errorMsg = registerPage.getValidationErrorText();
        }
        
        Assert.assertTrue(isSuccess, "Registration failed! Error displayed: " + errorMsg);
    }

    @AfterMethod
    public void tearDown() {
        // 6. Always close the browser after the test completes
        if (driver != null) {
            driver.quit();
        }
    }
}