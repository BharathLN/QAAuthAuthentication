package com.qa.auth;

import com.qa.auth.pages.LoginPage;
import com.qa.auth.pages.MyAccountPage;
import com.qa.auth.pages.RegisterPage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class AuthenticationTest extends BaseTest {

    private static final String PASSWORD = "Strongpass1";

    private String uniqueEmail() {
        return "qa.tester." + System.currentTimeMillis() + "@example.test";
    }

    @Test(description = "1. Successful registration")
    public void testSuccessfulRegistration() {
        RegisterPage registerPage = new RegisterPage(driver);
        registerPage.open(BASE_URL);
        registerPage.register("Kumar", "Prajwal", uniqueEmail(), PASSWORD, PASSWORD);

        Assert.assertTrue(registerPage.isRegistrationSuccessful(), "Registration should succeed");
    }

    @Test(description = "2. Registration with duplicate email")
    public void testDuplicateEmailRegistration() {
        String email = uniqueEmail();
        RegisterPage registerPage = new RegisterPage(driver);

        registerPage.open(BASE_URL);
        registerPage.register("Pratap", "Kumar", email, PASSWORD, PASSWORD);

        registerPage.open(BASE_URL);
        registerPage.register("pratap", "Kumar", email, PASSWORD, PASSWORD);

        String error = registerPage.getValidationErrorText();
        Assert.assertTrue(error.toLowerCase().contains("already exist"), "Expected duplicate email error");
    }

    @Test(description = "3. Successful login")
    public void testSuccessfulLogin() {
        String email = uniqueEmail();

        RegisterPage registerPage = new RegisterPage(driver);
        registerPage.open(BASE_URL);
        registerPage.register("Login", "User", email, PASSWORD, PASSWORD);

        LoginPage loginPage = new LoginPage(driver);
        loginPage.open(BASE_URL);
        loginPage.login(email, PASSWORD);

        Assert.assertTrue(loginPage.isLoggedIn(), "User should be logged in");
    }

    @Test(description = "4. Login with invalid password")
    public void testLoginWithInvalidPassword() {
        String email = uniqueEmail();

        RegisterPage registerPage = new RegisterPage(driver);
        registerPage.open(BASE_URL);
        registerPage.register("Wrong", "Password", email, PASSWORD, PASSWORD);

        LoginPage loginPage = new LoginPage(driver);

        // Registration auto-logs the user in on this site, so log out first
        if (loginPage.isLoggedIn()) {
            loginPage.logout();
        }

        loginPage.open(BASE_URL);
        loginPage.login(email, "IncorrectPassword99");

        Assert.assertFalse(loginPage.isLoggedIn(), "User should not be logged in with wrong password");
    }

    @Test(description = "5. Access dashboard without login (redirect)")
    public void testAccessAccountPageWithoutLogin() {
        MyAccountPage myAccountPage = new MyAccountPage(driver);
        myAccountPage.openDirectly(BASE_URL);

        Assert.assertTrue(myAccountPage.isRedirectedToLogin(), "Should redirect to login page");
    }
}